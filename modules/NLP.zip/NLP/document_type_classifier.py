# -*- coding: utf-8 -*-
"""
document_type_classifier.py — V25 generic multi-document

But : typer chaque document de manière générique, sans règle liée à un projet précis.
Ce typage sert ensuite à pondérer les preuves, mais il ne décide jamais seul du CIR.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Dict


def _norm(s: str) -> str:
    s = str(s or "").lower()
    tr = str.maketrans("àâäéèêëîïôöùûüç’`´", "aaaeeeeiioouuuc'''")
    s = s.translate(tr)
    s = re.sub(r"[^a-z0-9]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def _has(pattern: str, text: str) -> bool:
    return re.search(pattern, text, flags=re.IGNORECASE) is not None


TYPE_CONFIG = {
    "concept_projet": {"policy": "core_or_useful", "weight": 1.25},
    "note_projet": {"policy": "core_or_useful", "weight": 1.15},
    "presentation_projet": {"policy": "core_or_useful", "weight": 1.05},
    "rapport_test": {"policy": "core_or_useful", "weight": 1.20},
    "resultats_mesures": {"policy": "core_or_useful", "weight": 1.20},
    "brevet_invention": {"policy": "core_or_useful", "weight": 1.20},
    "preuve_depot": {"policy": "core_or_useful", "weight": 1.05},
    "methodologie_protocole": {"policy": "secondary", "weight": 0.75},
    "notice_memoire_technique": {"policy": "secondary", "weight": 0.55},
    "etat_art_bibliographie": {"policy": "comparison_only", "weight": 0.55},
    "norme_reglementation": {"policy": "context_only", "weight": 0.25},
    "plan_schema": {"policy": "context_only", "weight": 0.20},
    "administratif": {"policy": "context_only", "weight": 0.10},
    "template_formulaire": {"policy": "context_only", "weight": 0.10},
    "unknown_document": {"policy": "secondary", "weight": 0.55},
}


def _make(doc_type: str, confidence: float, reason: str) -> Dict[str, Any]:
    cfg = TYPE_CONFIG.get(doc_type, TYPE_CONFIG["unknown_document"])
    return {
        "document_type": doc_type,
        "document_type_confidence": confidence,
        "source_policy": cfg["policy"],
        "document_weight": cfg["weight"],
        "document_type_reason": reason,
    }


def classify_document_type(doc: Dict[str, Any]) -> Dict[str, Any]:
    name_raw = str(doc.get("document") or doc.get("file_name") or "")
    name = _norm(Path(name_raw).name)
    text = _norm(str(doc.get("text") or "")[:12000])
    joined = f"{name} {text}"
    origin = str(doc.get("content_origin") or "unknown")

    # 1) Documents explicitement projet / concept / prototype
    if _has(r"\b(concept|concepts|prototype|prototypage|solution retenue|solution technique|architecture de solution|choix technique|conception)\b", joined):
        return _make("concept_projet", 0.92, "concept/prototype/solution technique")

    if _has(r"\b(note de cadrage|cadrage|brief|expression besoin|expression du besoin|fiche projet|note projet|cdc|cahier des charges)\b", joined):
        return _make("note_projet", 0.92, "note projet / cadrage")

    if _has(r"\b(presentation|présentation|slides?|pptx|avancement|point projet|travaux)\b", joined):
        return _make("presentation_projet", 0.88, "présentation / avancement")

    # 2) Preuves R&D / propriété industrielle / essais
    if _has(r"\b(brevet|invention|inventeur|revendication|claims?|patent|inpi|propriete industrielle|propriété industrielle)\b", joined):
        return _make("brevet_invention", 0.92, "brevet / invention")

    if _has(r"\b(depot|dépôt|recepisse|récépissé|horodatage|preuve de depot|preuve de dépôt)\b", joined):
        return _make("preuve_depot", 0.86, "preuve de dépôt / traçabilité")

    if _has(r"\b(rapport d essais?|rapport de tests?|pv d essais?|compte rendu d essais?|resultats d essais?|résultats d essais?|mesures?|campagne de mesure|validation expérimentale|test de validation)\b", joined):
        return _make("rapport_test", 0.90, "rapport test / mesures")

    if _has(r"\b(resultats?|résultats?|metriques?|métriques?|performances?|courbes?|graphiques?|tableau comparatif|comparaison)\b", name):
        return _make("resultats_mesures", 0.85, "résultats / métriques dans le nom")

    # 3) Normes / réglementation / exigences externes
    if _has(r"\b(norme|standard|reglement|règlement|reglementation|réglementation|certification|label|iso|astm|ista|en\s?[0-9]{2,}|nf\s?[a-z]?)\b", joined):
        return _make("norme_reglementation", 0.88, "norme / certification / réglementation")

    # 4) Méthodes / notices / plans / état de l'art
    if _has(r"\b(methodologie|méthodologie|protocole|demarche|démarche|plan d essais|plan de test|procedure|procédure|mode operatoire|mode opératoire)\b", joined):
        return _make("methodologie_protocole", 0.82, "méthodologie / protocole")

    if _has(r"\b(benchmark|comparatif|baseline|etat de l art|état de l art|state of art|survey|review|bibliographie|references|références|article scientifique|publication|doi|arxiv|ieee)\b", joined):
        return _make("etat_art_bibliographie", 0.82, "état de l'art / bibliographie")

    if _has(r"\b(plan|coupe|schema|schéma|elevation|élévation|masse|rdc|r\+\d|niveau|implantation|dessin|a0|a1)\b", name):
        return _make("plan_schema", 0.88, "plan / schéma")

    if _has(r"\b(notice|memoire|mémoire|descriptif|explicatif|technique|dce|pro|aps|apd|doe|aor)\b", joined):
        return _make("notice_memoire_technique", 0.80, "notice / mémoire technique")

    if _has(r"\b(cerfa|budget|facture|devis|planning|calendrier|administratif|contrat|marche|marché|honoraires|annexe financière|finance)\b", joined):
        return _make("administratif", 0.78, "administratif / planning / financier")

    if _has(r"\b(template|trame|modele|modèle|formulaire|exemple|a remplir|à remplir)\b", joined):
        return _make("template_formulaire", 0.85, "template / formulaire")

    # Origine déjà connue par un module amont.
    if origin == "project_core":
        return _make("note_projet", 0.70, "content_origin project_core")
    if origin == "state_of_art":
        return _make("etat_art_bibliographie", 0.70, "content_origin state_of_art")
    if origin == "metadata":
        return _make("administratif", 0.65, "content_origin metadata")

    return _make("unknown_document", 0.50, "fallback")


def enrich_document_type(doc: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(doc or {})
    info = classify_document_type(out)
    out.update(info)
    # source_weight reste compatible avec l'ancien pipeline.
    out["source_weight"] = float(out.get("source_weight") or info.get("document_weight") or 0.55)
    return out
