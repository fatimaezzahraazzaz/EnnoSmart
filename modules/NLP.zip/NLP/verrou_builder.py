# -*- coding: utf-8 -*-
from __future__ import annotations

import re
from typing import Dict, Any, List, Optional

# ---------------------------------------------------------------------
# Normalisation
# ---------------------------------------------------------------------

def norm(text: str) -> str:
    text = str(text or "").lower()
    text = text.replace("é", "e").replace("è", "e").replace("ê", "e")
    text = text.replace("à", "a").replace("ç", "c")
    text = text.replace("ù", "u").replace("ô", "o")
    text = text.replace("’", "'")
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def _safe_float(x: Any, default: float = 0.0) -> float:
    try:
        return float(x or 0.0)
    except Exception:
        return default


def _is_too_short(text: str, min_len: int = 30) -> bool:
    text = str(text or "").strip()
    return len(text) < min_len


def _looks_like_noise(text: str) -> bool:
    low = norm(text)
    if not low:
        return True
    if _is_too_short(low):
        return True
    chars = len(low)
    digits = sum(c.isdigit() for c in low)
    pipes = low.count("|")
    slashes = low.count("/")
    if chars > 0 and digits / chars > 0.55:
        return True
    if pipes >= 6:
        return True
    if slashes >= 10 and len(low) < 180:
        return True
    admin_patterns = ["siret", "page ", "révision", "revision", "indice",
                      "date", "auteur", "signature", "confidentiel",
                      "copyright", "tous droits", "web :", "www."]
    hits = sum(1 for p in admin_patterns if p in low)
    if hits >= 3 and len(low) < 200:
        return True
    return False


# Règles lexicales pour capturer les verrous (élargi)
VERROU_PATTERNS = [
    r"ne permet pas de", r"limit(e|ation) majeure", r"verrou technologique",
    r"bloquant", r"difficulté majeure", r"problème non résolu",
    r"manque de (moyens|banc d'essai|instrumentation)", r"impossible de",
    r"ne dispose pas de", r"absence de", r"insuffisance de",
    r"frein (majeur|principal)", r"obstacle (majeur|principal)",
    r"ne satisfait pas", r"hors de portée", r"non maîtrisé", r"non contrôlé",
    r"verrou", r"challenge", r"difficulté", r"desequilibre", r"déséquilibre",
    r"vibration", r"usure", r"fuite", r"soufflage", r"perte de charge"
]

# Patterns à ignorer (faux verrous - très sélectif)
NOISE_PATTERNS = [
    r"soft dice loss", r"cross[-\s]entropy", r"backpropagation",
    r"learning rate", r"batch size", r"validation loss", r"optimizer",
    r"github", r"repository", r"doi", r"arxiv", r"ieee"
]

CONTEXT_ONLY_TYPES = {"norme_reglementation", "plan_schema", "administratif", "template_formulaire"}
SECONDARY_TYPES = {"notice_memoire_technique", "etat_art_bibliographie"}
CORE_TYPES = {"concept_projet", "brevet", "preuve_depot_brevet", "rapport_test", "note_projet", "presentation_projet", "methodologie_protocole"}


def has_verrou_patterns(text: str) -> bool:
    low = norm(text)
    for pat in VERROU_PATTERNS:
        if re.search(pat, low):
            return True
    return False


def is_noise_verrou(text: str) -> bool:
    low = norm(text)
    for pat in NOISE_PATTERNS:
        if re.search(pat, low):
            return True
    return False


def local_verrou_score(item: Dict[str, Any], domain_context: Optional[str] = None) -> float:
    role = item.get("role")
    confidence = _safe_float(item.get("confidence") or item.get("model_confidence"))
    verrou_score = _safe_float(item.get("verrou_score"))
    rank_score_val = _safe_float(item.get("rank_score"))
    dtype = item.get("document_type")

    # Vérifier si un autre rôle domine
    scores = item.get("scores", {})
    max_other = 0.0
    for r, s in scores.items():
        if r != "verrou" and r in ["objectif", "methode", "resultat", "contribution", "parametre"]:
            max_other = max(max_other, _safe_float(s))
    
    # Pénalité si un autre rôle est plus probable
    penalty = 1.0
    if max_other > 0.7:
        penalty = 0.3
    elif max_other > 0.6:
        penalty = 0.5
    elif max_other > 0.5:
        penalty = 0.7

    score = 0.0
    if role == "verrou":
        score += 0.55
    elif role == "limite":
        score += 0.30  # réduit de 0.35 à 0.30
    else:
        score += 0.0

    score += min(confidence, 1.0) * 0.15  # réduit de 0.20 à 0.15
    score += min(verrou_score, 1.0) * 0.30  # réduit de 0.35 à 0.30
    score += min(rank_score_val, 1.5) * 0.08  # réduit de 0.10 à 0.08

    if item.get("content_origin") == "project_core":
        score += 0.05
    if dtype in CORE_TYPES:
        score += 0.18
    elif dtype in SECONDARY_TYPES:
        score -= 0.20
    elif dtype in CONTEXT_ONLY_TYPES:
        score -= 0.55
    if item.get("quality_status") == "strict":
        score += 0.03  # réduit de 0.05 à 0.03
    if has_verrou_patterns(item.get("text", "")):
        score += 0.08  # réduit de 0.12 à 0.08
    if domain_context and domain_context in norm(item.get("text", "")):
        score += 0.04  # réduit de 0.06 à 0.04

    # Bonus section hint plus modéré
    hint = item.get("section_role_hint")
    if hint == "verrou":
        score += 0.10  # réduit de 0.20 à 0.10
    elif hint == "limite":
        score += 0.05  # réduit de 0.10 à 0.05

    score = score * penalty  # application de la pénalité
    return round(max(0.0, min(score, 1.2)), 4)


def should_keep_direct_verrou(item: Dict[str, Any]) -> bool:
    if item.get("document_type") in CONTEXT_ONLY_TYPES:
        item["non_verrou_reason"] = "document contextuel/normatif : contrainte ou méthode, pas verrou R&D"
        return False
    text = item.get("text", "")
    if _looks_like_noise(text) or is_noise_verrou(text):
        return False

    role = item.get("role")
    confidence = _safe_float(item.get("confidence") or item.get("model_confidence"))
    verrou_score = _safe_float(item.get("verrou_score"))
    quality = item.get("quality_status")

    if role != "verrou":
        return False

    if quality in ("strict", "verrou_boosted", "verrou_score_high") and confidence >= 0.45 and verrou_score >= 0.35:
        return True
    if verrou_score >= 0.50:
        return True
    if has_verrou_patterns(text) and verrou_score >= 0.35:
        return True

    return False


def should_promote_as_local_verrou(item: Dict[str, Any]) -> bool:
    if item.get("document_type") in CONTEXT_ONLY_TYPES:
        return False
    text = item.get("text", "")
    if _looks_like_noise(text):
        return False
    
    role = item.get("role")
    verrou_score = _safe_float(item.get("verrou_score"))
    hint = item.get("section_role_hint")
    
    # Vérifier les autres rôles dominants
    scores = item.get("scores", {})
    objectif_conf = _safe_float(scores.get("objectif", 0.0))
    methode_conf = _safe_float(scores.get("methode", 0.0))
    resultat_conf = _safe_float(scores.get("resultat", 0.0))
    
    # Ne pas promouvoir si objectif ou methode domine très clairement
    if objectif_conf > 0.75 or methode_conf > 0.70:
        return False
    
    # Promotion uniquement pour les limites ou résultats très proches
    if role == "limite" and verrou_score >= 0.55:  # augmenté de 0.45 à 0.55
        return True
    
    if role == "resultat" and verrou_score >= 0.70 and resultat_conf < 0.65:  # plus strict
        return True
    
    if hint == "verrou" and verrou_score >= 0.50:  # augmenté de 0.35 à 0.50
        return True
    
    if hint == "limite" and verrou_score >= 0.55:  # augmenté de 0.40 à 0.55
        return True
    
    # Règle lexicale plus sélective
    if has_verrou_patterns(text) and verrou_score >= 0.55 and role in {"limite", "resultat"}:
        return True
    
    return False

def make_promoted_verrou(item: Dict[str, Any]) -> Dict[str, Any]:
    x = dict(item)
    x["role"] = "verrou"
    x["quality_status"] = "promoted_local"
    x["verrou_source"] = "promoted_from_local_evidence"
    x["accepted_for_synthesis"] = True
    x["needs_human_validation"] = True
    x["local_verrou_score"] = local_verrou_score(item)
    x["promoted_from_role"] = item.get("role")
    x["promoted_from_category"] = item.get("_source_category")
    return x


def collect_candidate_sources(pack: Dict[str, Any]) -> List[Dict[str, Any]]:
    sources = []
    categories = [
        "verrous_rnd_locaux", "limites_locales", "methodes_locales",
        "resultats_locaux", "parametres_locaux", "objectifs_locaux",
    ]
    for key in categories:
        for item in pack.get(key, []) or []:
            if not isinstance(item, dict):
                continue
            x = dict(item)
            x["_source_category"] = key
            sources.append(x)
    return sources


def build_local_verrous(pack: Dict[str, Any], max_verrous: int = 20,
                        domain_context: Optional[str] = None) -> List[Dict[str, Any]]:
    sources = collect_candidate_sources(pack)
    direct = []
    promoted = []

    for item in sources:
        item["local_verrou_score"] = local_verrou_score(item, domain_context=domain_context)

        if should_keep_direct_verrou(item):
            x = dict(item)
            x["verrou_source"] = x.get("verrou_source") or "direct_model_evidence"
            x["accepted_for_synthesis"] = True
            x["needs_human_validation"] = True
            direct.append(x)
        elif should_promote_as_local_verrou(item):
            promoted.append(make_promoted_verrou(item))

    direct = sorted(direct, key=lambda x: _safe_float(x.get("local_verrou_score")), reverse=True)
    promoted = sorted(promoted, key=lambda x: _safe_float(x.get("local_verrou_score")), reverse=True)

    final = []
    seen = set()

    for item in direct + promoted:
        key = f"{norm(item.get('document', ''))}|{norm(item.get('role', ''))}|{norm(item.get('text', ''))[:180]}"
        if key in seen:
            continue
        seen.add(key)
        final.append(item)
        if len(final) >= max_verrous:
            break

    for i, item in enumerate(final, start=1):
        item.setdefault("cluster_id", f"verrou_local_{i:03d}")

    return final


def enrich_evidence_pack_with_verrous(pack: Dict[str, Any],
                                       domain_context: Optional[str] = None) -> Dict[str, Any]:
    pack = dict(pack or {})
    final_verrous = build_local_verrous(pack, max_verrous=20, domain_context=domain_context)
    pack["verrous_rnd_locaux"] = final_verrous
    return pack